# شروع سریع از داخل BotFather

برای راه‌اندازی اولیه فقط چهار فایل لازم است. در BotFather برو به:

```text
@BotFather → My Bots → ربات → Serverless → Enable
```

فایل‌های زیر را با همین نام بساز و بعد `Save/Deploy` و سپس `Database → Apply migration` را بزن.

در `auth.js` مقدار `ADMIN_ID` را با شناسه تلگرام خودت عوض کن.

## schema.js

```js
import { table, integer, text, sql } from 'sdk/db';
export const expenses = table('expenses', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  telegramId: integer('telegram_id').notNull(), employee: text('employee').notNull(),
  description: text('description').notNull(), amount: integer('amount'),
  currency: text('currency').notNull().default('TOMAN'), payment: text('payment'),
  status: text('status').notNull().default('NEEDS_COMPLETION'),
  createdAt: text('created_at').default(sql`(datetime('now'))`),
});
```

## auth.js

```js
export const ADMIN_ID = 123456789; // این عدد را عوض کن
export const isAllowed = id => Number(id) === Number(ADMIN_ID);
export const digits = s => String(s || '').replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
export function parse(text) {
  const n = digits(text); const m = n.match(/([0-9][0-9,،.\s]*)\s*(تومان|ریال)?/);
  return { description: text, amount: m ? Number(m[1].replace(/[،,\s]/g, '')) : null, currency: m?.[2] === 'ریال' ? 'IRR' : 'TOMAN', payment: text.includes('تنخواه') ? 'کارت تنخواه' : text.includes('شرکت') ? 'کارت شرکت' : null };
}
```

## handlers/message.js

```js
import { api, db } from 'sdk';
import { eq, desc } from 'sdk/db';
import { expenses } from '../schema.js';
import { isAllowed, parse } from '../auth.js';
const kb = { keyboard: [[{ text: 'گزارش من' }, { text: 'راهنما' }]], resize_keyboard: true };
export default async function (m) {
  const id = m.from.id, chat = m.chat.id, text = m.text || m.caption || '';
  if (text === '/start') return api.sendMessage({ chat_id: chat, text: `سلام!\nشناسه شما: ${id}\n\nتوضیح هزینه را همراه مبلغ و روش پرداخت بفرستید.`, reply_markup: kb });
  if (!isAllowed(id)) return api.sendMessage({ chat_id: chat, text: `دسترسی فعال نیست. شناسه شما: ${id}` });
  if (text === 'راهنما') return api.sendMessage({ chat_id: chat, text: 'مثال: خرید لوازم اداری مبلغ ۲۵۰۰۰۰ تومان کارت شرکت' });
  if (text === 'گزارش من') { const rows = await db.select().from(expenses).where(eq(expenses.telegramId, id)).orderBy(desc(expenses.id)).limit(20).all(); return api.sendMessage({ chat_id: chat, text: rows.length ? rows.map(r => `${r.description} — ${r.amount || 'نامشخص'} ${r.currency}`).join('\n') : 'هنوز هزینه‌ای ثبت نشده است.' }); }
  const p = parse(text); const status = p.amount && p.payment ? 'PENDING_REVIEW' : 'NEEDS_COMPLETION';
  await db.insert(expenses).values({ telegramId: id, employee: m.from.first_name || String(id), ...p, status }).run();
  return api.sendMessage({ chat_id: chat, text: `هزینه دریافت شد.\nمبلغ: ${p.amount || 'نامشخص'} ${p.currency}\nروش پرداخت: ${p.payment || 'نامشخص'}\nوضعیت: ${status === 'PENDING_REVIEW' ? 'در انتظار بررسی' : 'نیازمند تکمیل'}` });
}
```

## handlers/callback_query.js

```js
import { api } from 'sdk';
export default async function (q) { await api.answerCallbackQuery({ callback_query_id: q.id }); }
```

برای گرفتن شناسه تلگرام، به `@userinfobot` پیام بده. این نسخه برای شروع سریع ثبت متن و گزارش شخصی را فعال می‌کند؛ ویس، OCR و گزارش مدیر را بعداً روی همین پروژه اضافه می‌کنیم.
