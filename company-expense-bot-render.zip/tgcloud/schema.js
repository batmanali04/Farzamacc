import { table, integer, text, sql } from 'sdk/db';

export const users = table('users', {
  telegramId: integer('telegram_id').primaryKey(),
  fullName: text('full_name').notNull(),
  role: text('role').notNull().default('employee'),
  active: integer('active').notNull().default(1),
  createdAt: text('created_at').default(sql`(datetime('now'))`),
});

export const expenses = table('expenses', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  expenseCode: text('expense_code').notNull(),
  telegramId: integer('telegram_id').notNull(),
  employeeName: text('employee_name').notNull(),
  gregorianDate: text('gregorian_date').notNull(),
  jalaliDate: text('jalali_date').notNull(),
  iranTime: text('iran_time').notNull(),
  description: text('description'),
  amount: integer('amount'),
  currency: text('currency').notNull().default('TOMAN'),
  paymentMethod: text('payment_method'),
  category: text('category'),
  receiptPath: text('receipt_path'),
  voicePath: text('voice_path'),
  transcript: text('transcript'),
  ocrText: text('ocr_text'),
  status: text('status').notNull().default('NEEDS_COMPLETION'),
  sourceHash: text('source_hash'),
  createdAt: text('created_at').default(sql`(datetime('now'))`),
  updatedAt: text('updated_at').default(sql`(datetime('now'))`),
});

export const auditLogs = table('audit_logs', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  telegramId: integer('telegram_id'),
  action: text('action').notNull(),
  expenseCode: text('expense_code'),
  details: text('details'),
  createdAt: text('created_at').default(sql`(datetime('now'))`),
});

export const drafts = table('drafts', {
  telegramId: integer('telegram_id').primaryKey(),
  payload: text('payload').notNull(),
  updatedAt: text('updated_at').default(sql`(datetime('now'))`),
});
