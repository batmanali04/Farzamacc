import { api } from 'sdk';
import { requireUser } from '../lib/access.js';
import { fa } from '../lib/i18n.js';
import { parseExpenseText, missingFields } from '../lib/parse.js';
import { saveDraft, loadDraft, createExpense, summary } from '../lib/expense.js';
import { transcribeVoice, ocrReceipt } from '../lib/ai.js';

const menu = { keyboard: [[{ text: 'ثبت هزینه جدید' }, { text: 'هزینه‌های من' }], [{ text: 'راهنما' }]], resize_keyboard: true };
const confirm = { inline_keyboard: [[{ text: '✅ ثبت نهایی', callback_data: 'expense:confirm' }, { text: '✏️ اصلاح', callback_data: 'expense:edit' }]] };
export default async function (message) {
  const user = await requireUser(message); if (!user) return;
  const chatId = message.chat.id; const text = message.text || message.caption || '';
  if (text === '/start') return api.sendMessage({ chat_id: chatId, text: fa.welcome, reply_markup: menu });
  if (text === '/help' || text === 'راهنما') return api.sendMessage({ chat_id: chatId, text: fa.help, reply_markup: menu });
  if (text === 'ثبت هزینه جدید') { await saveDraft(user.telegramId, {}); return api.sendMessage({ chat_id: chatId, text: 'توضیح هزینه را بفرستید؛ می‌توانید مبلغ، واحد پول، روش پرداخت و دسته را هم در همان پیام بنویسید.' }); }
  if (text === 'هزینه‌های من') return api.sendMessage({ chat_id: chatId, text: 'برای گزارش شخصی از API داخلی استفاده کنید یا با مدیر تماس بگیرید.' });
  let draft = await loadDraft(user.telegramId) || {};
  const parsed = parseExpenseText(text); draft = { ...draft, ...parsed, description: draft.description ? `${draft.description}\n${text}` : text };
  if (message.voice) draft.voiceFileId = message.voice.file_id;
  if (message.photo?.length) draft.receiptFileId = message.photo.at(-1).file_id;
  if (message.voice) { try { draft.transcript = await transcribeVoice(message.voice.file_id); if (draft.transcript) draft = { ...draft, ...parseExpenseText(draft.transcript), description: `${draft.description}\n${draft.transcript}` }; } catch (e) { console.warn('voice enrichment failed'); } }
  if (message.photo?.length) { try { draft.ocrText = await ocrReceipt(message.photo.at(-1).file_id); } catch (e) { console.warn('receipt OCR failed'); } }
  await saveDraft(user.telegramId, draft);
  const missing = missingFields(draft);
  if (missing.length) return api.sendMessage({ chat_id: chatId, text: `${fa.incomplete}\n\nاطلاعات فعلی:\n${summary(draft)}\n\nموارد ناقص: ${missing.join('، ')}` });
  return api.sendMessage({ chat_id: chatId, text: 'لطفاً خلاصه را بررسی کنید:\n\n' + summary(draft), reply_markup: confirm });
}
