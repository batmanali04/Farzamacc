import { api } from 'sdk';
import { eq } from 'sdk/db';
import { users } from '../schema.js';
import { loadDraft, createExpense, clearDraft, summary } from '../lib/expense.js';
export default async function (query) {
  const chatId = query.message.chat.id; const id = query.from.id;
  await api.answerCallbackQuery({ callback_query_id: query.id });
  const user = await dbUser(id); if (!user) return;
  if (query.data === 'expense:confirm') { const draft = await loadDraft(id); if (!draft) return api.sendMessage({ chat_id: chatId, text: 'پیش‌نویسی برای ثبت وجود ندارد.' }); const saved = await createExpense(user, draft); await clearDraft(id); return api.sendMessage({ chat_id: chatId, text: `✅ ${saved.expenseCode}\n${summary(saved)}\n\n${saved.status === 'PENDING_REVIEW' ? 'در انتظار بررسی مدیر است.' : 'نیازمند تکمیل اطلاعات است.'}` }); }
  if (query.data === 'expense:edit') return api.sendMessage({ chat_id: chatId, text: 'مقدار اصلاحی را به‌صورت پیام متنی یا صوتی ارسال کنید.' });
}
async function dbUser(id) { const { db } = await import('sdk'); return db.select().from(users).where(eq(users.telegramId, id)).get(); }
