import { db, EndpointError } from 'sdk';
import { eq, desc } from 'sdk/db';
import { expenses } from '../schema.js';
export default async function (input, ctx) {
  const user = ctx.initData.user; if (!user) throw new EndpointError('کاربر معتبر نیست');
  const rows = await db.select().from(expenses).where(eq(expenses.telegramId, user.id)).orderBy(desc(expenses.id)).limit(Math.min(Number(input?.limit || 50), 100)).all();
  return rows;
}
