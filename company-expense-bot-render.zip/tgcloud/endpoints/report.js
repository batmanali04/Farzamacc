import { db, EndpointError } from 'sdk';
import { expenses, users } from '../schema.js';
import { eq } from 'sdk/db';
export default async function (input, ctx) {
  const admin = ctx.initData.user; const u = await db.select().from(users).where(eq(users.telegramId, admin.id)).get();
  if (u?.role !== 'admin') throw new EndpointError('فقط مدیر مجاز است');
  const rows = await db.select().from(expenses).all();
  const filtered = rows.filter(r => (!input?.status || r.status === input.status) && (!input?.telegramId || String(r.telegramId) === String(input.telegramId)));
  const total = filtered.reduce((s, r) => s + (r.amount || 0), 0);
  return { count: filtered.length, total, currency: 'TOMAN', expenses: filtered };
}
