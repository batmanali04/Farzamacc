import test from 'node:test'; import assert from 'node:assert/strict';
import { normalizeDigits } from '../tgcloud/lib/i18n.js'; import { parseExpenseText, missingFields } from '../tgcloud/lib/parse.js'; import { toJalali } from '../tgcloud/lib/time.js';
test('normalizes Persian and Arabic digits', () => assert.equal(normalizeDigits('۱۲۳٤۵'), '12345'));
test('parses Persian expense text', () => { const e = parseExpenseText('خرید لوازم اداری، مبلغ ۲۵۰۰۰۰ تومان با کارت شرکت'); assert.equal(e.amount, 250000); assert.equal(e.currency, 'TOMAN'); assert.equal(e.paymentMethod, 'کارت شرکت'); assert.equal(e.category, 'لوازم اداری'); });
test('converts Gregorian to Jalali', () => assert.equal(toJalali(2026, 11, 22), '1405/09/01'));
test('detects missing fields', () => assert.deepEqual(missingFields({ amount: 1 }), ['paymentMethod','category']));
