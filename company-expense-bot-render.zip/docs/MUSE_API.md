# قرارداد اتصال Muse

در Telegram Serverless، endpointها فقط از Mini App و با `ctx.initData` معتبر قابل فراخوانی هستند. بنابراین Muse باید این عملیات را به ابزارهای زیر map کند:

| ابزار Muse | endpoint | ورودی |
|---|---|---|
| `list_expenses` | `listExpenses` | `{limit}` |
| `get_report` | `report` | `{status?, telegramId?}` |
| `search_expenses` | `report` | فیلترهای بالا و فیلتر سمت Muse |

برای `mark_processed` و `move_to_needs_review` یک endpoint نوشتنی مشابه `report.js` بسازید که نقش مدیر را بررسی کند و فقط status را از فهرست مجاز بپذیرد. این تفکیک از ثبت وضعیت دلخواه توسط کاربر جلوگیری می‌کند.

اگر Muse به endpoint عمومی HTTP نیاز دارد، یک gateway کوچک روی Railway/Render قرار دهید که با یک service secret به دیتابیس/فضای ذخیره‌سازی متصل شود؛ هرگز bot token یا `ctx.initData` را در کلاینت قرار ندهید.
